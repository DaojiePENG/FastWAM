"""FastWAM package."""
